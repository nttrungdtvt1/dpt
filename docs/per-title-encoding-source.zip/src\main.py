"""CLI for the per-title VOD encoding demo."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

SRC_DIR = Path(__file__).resolve().parent
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from config import default_config_path, load_config
from pipeline import run_pipeline
from utils.ffmpeg_tools import find_ffmpeg_tools
from utils.logger import setup_logging
from utils.sample_video import make_sample_video


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Content-aware bitrate ladder selection (experimental) for VOD."
    )
    parser.add_argument("--config", type=Path, default=None, help="Duong dan config YAML")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("check-env", help="Kiem tra FFmpeg/FFprobe")

    sample = sub.add_parser("make-sample", help="Tao video mau ngan")
    sample.add_argument("--output", type=Path, default=Path("data/samples/sample_testsrc.mp4"))
    sample.add_argument("--seconds", type=float, default=3.0)
    sample.add_argument("--size", default="1280x720")
    sample.add_argument("--pattern", default="testsrc", choices=["testsrc", "testsrc2", "smptebars"])

    analyze = sub.add_parser("analyze", help="Chi phan tich, khong encode")
    analyze.add_argument("videos", nargs="+", type=Path)

    run = sub.add_parser("run", help="Chay toan bo pipeline")
    run.add_argument("videos", nargs="+", type=Path)
    run.add_argument("--output", type=Path, default=Path("results"))
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    logger = setup_logging(logging.INFO)
    try:
        tools = find_ffmpeg_tools()
    except Exception as exc:
        logger.error("%s", exc)
        return 2

    if args.command == "check-env":
        print(f"ffmpeg: {tools.ffmpeg}")
        print(f"ffprobe: {tools.ffprobe}")
        return 0

    cfg = load_config(args.config or default_config_path())

    if args.command == "make-sample":
        path = make_sample_video(tools, args.output, seconds=args.seconds, size=args.size, pattern=args.pattern)
        print(path)
        return 0

    if args.command == "analyze":
        from analyzer.feature_extractor import extract_features
        from ladder.models import build_fixed_ladder, build_per_title_ladder, validate_ladder

        for video in args.videos:
            features = extract_features(video, tools, cfg, work_dir=Path("results") / "work")
            fixed = build_fixed_ladder(features.meta, cfg)
            per_title = build_per_title_ladder(features.meta, cfg, features.adjusted_k)
            validate_ladder(fixed, features.meta, cfg)
            validate_ladder(per_title, features.meta, cfg)
            print(
                json.dumps(
                    {
                        "video": str(video),
                        "size": f"{features.meta.width}x{features.meta.height}",
                        "fps": features.meta.fps,
                        "duration": features.meta.duration_seconds,
                        "si": features.complexity.si,
                        "ti": features.complexity.ti,
                        "label": features.adjusted_label,
                        "k": features.adjusted_k,
                        "fixed": [item.__dict__ for item in fixed],
                        "per_title": [item.__dict__ for item in per_title],
                    },
                    indent=2,
                    ensure_ascii=False,
                )
            )
        return 0

    if args.command == "run":
        summary = run_pipeline(args.videos, args.output, tools, cfg)
        print(json.dumps(summary, indent=2, ensure_ascii=False))
        return 0

    logger.error("Lenh khong ho tro.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
