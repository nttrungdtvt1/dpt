"""Ladder data types, fixed baseline, per-title adjustment, and validation."""

from __future__ import annotations

from dataclasses import dataclass

from analyzer.video_probe import VideoMeta
from config import AppConfig, LadderSpec


@dataclass(frozen=True)
class LadderRung:
    name: str
    width: int
    height: int
    bitrate_kbps: int
    source: str


def even(value: int) -> int:
    return value if value % 2 == 0 else value - 1


def size_for_height(meta: VideoMeta, target_height: int) -> tuple[int, int]:
    height = even(min(target_height, meta.height))
    if height < 2:
        raise ValueError("Chieu cao ladder khong hop le.")
    width = even(int(round(meta.width * height / meta.height)))
    width = max(width, 2)
    return width, height


def materialize(spec: LadderSpec, meta: VideoMeta, source: str) -> LadderRung | None:
    if spec.height > meta.height:
        return None
    width, height = size_for_height(meta, spec.height)
    return LadderRung(
        name=spec.name,
        width=width,
        height=height,
        bitrate_kbps=int(spec.bitrate_kbps),
        source=source,
    )


def build_fixed_ladder(meta: VideoMeta, cfg: AppConfig) -> list[LadderRung]:
    rungs: list[LadderRung] = []
    for spec in cfg.fixed_ladder:
        rung = materialize(spec, meta, "fixed")
        if rung is not None:
            rungs.append(rung)
    if not rungs:
        raise ValueError("Khong con bac ladder nao phu hop voi do phan giai nguon.")
    return rungs


def round_bitrate(value: float, step: int) -> int:
    if step <= 0:
        return int(round(value))
    return int(max(step, round(value / step) * step))


def build_per_title_ladder(meta: VideoMeta, cfg: AppConfig, k: float) -> list[LadderRung]:
    step = int(cfg.complexity.get("bitrate_step_kbps", 50))
    min_br = int(cfg.complexity.get("min_bitrate_kbps", 150))
    max_br = int(cfg.complexity.get("max_bitrate_kbps", 8000))
    rungs: list[LadderRung] = []
    for spec in cfg.fixed_ladder:
        base = materialize(spec, meta, "per_title")
        if base is None:
            continue
        bitrate = round_bitrate(base.bitrate_kbps * k, step)
        bitrate = min(max(bitrate, min_br), max_br)
        rungs.append(
            LadderRung(
                name=base.name,
                width=base.width,
                height=base.height,
                bitrate_kbps=bitrate,
                source="per_title",
            )
        )
    rungs = _ensure_increasing(rungs, step, max_br)
    if not rungs:
        raise ValueError("Per-title ladder rong.")
    return rungs


def _ensure_increasing(rungs: list[LadderRung], step: int, max_br: int) -> list[LadderRung]:
    if not rungs:
        return rungs
    out = [rungs[0]]
    for rung in rungs[1:]:
        prev = out[-1]
        bitrate = rung.bitrate_kbps
        if bitrate <= prev.bitrate_kbps:
            bitrate = min(max_br, prev.bitrate_kbps + step)
        out.append(
            LadderRung(
                name=rung.name,
                width=rung.width,
                height=rung.height,
                bitrate_kbps=bitrate,
                source=rung.source,
            )
        )
    return out


def validate_ladder(rungs: list[LadderRung], meta: VideoMeta, cfg: AppConfig) -> None:
    if not rungs:
        raise ValueError("Ladder rong.")
    min_br = int(cfg.complexity.get("min_bitrate_kbps", 150))
    max_br = int(cfg.complexity.get("max_bitrate_kbps", 8000))
    prev_br = 0
    for rung in rungs:
        if rung.width % 2 or rung.height % 2:
            raise ValueError(f"Kich thuoc le khong hop le yuv420p: {rung.width}x{rung.height}")
        if rung.width > meta.width or rung.height > meta.height:
            raise ValueError(f"Upscale bi cam: {rung.width}x{rung.height} > {meta.width}x{meta.height}")
        if rung.bitrate_kbps < min_br or rung.bitrate_kbps > max_br:
            raise ValueError(f"Bitrate ngoai bien: {rung.bitrate_kbps} kbps")
        if rung.bitrate_kbps <= prev_br:
            raise ValueError("Bitrate ladder phai tang dan.")
        prev_br = rung.bitrate_kbps
