"""Matplotlib charts for the comparison report."""

from __future__ import annotations

from pathlib import Path

from metrics.result_collector import ExperimentRow


def plot_results(rows: list[ExperimentRow], out_dir: Path) -> list[Path]:
    if not rows:
        raise ValueError("Khong co du lieu de ve bieu do.")
    import matplotlib.pyplot as plt

    out_dir.mkdir(parents=True, exist_ok=True)
    created: list[Path] = []

    videos = sorted({row.video for row in rows})
    methods = sorted({row.method for row in rows})

    fig, ax = plt.subplots(figsize=(9, 4.5))
    labels = [f"{row.video}\n{row.rung}" for row in rows]
    sizes_mb = [row.size_bytes / (1024 * 1024) for row in rows]
    colors = ["#4C78A8" if row.method == "fixed" else "#F58518" for row in rows]
    ax.bar(range(len(rows)), sizes_mb, color=colors)
    ax.set_xticks(range(len(rows)), labels, rotation=45, ha="right", fontsize=8)
    ax.set_ylabel("Dung luong (MB)")
    ax.set_title("Dung luong file theo bac va phuong phap")
    fig.tight_layout()
    path = out_dir / "file_size_by_rung.png"
    fig.savefig(path, dpi=120)
    plt.close(fig)
    created.append(path)

    fig, ax = plt.subplots(figsize=(7, 4.5))
    for method in methods:
        subset = [row for row in rows if row.method == method and row.ssim is not None]
        subset.sort(key=lambda item: item.actual_bitrate_kbps)
        if not subset:
            continue
        ax.plot(
            [row.actual_bitrate_kbps for row in subset],
            [row.ssim for row in subset],
            marker="o",
            label=method,
        )
    ax.set_xlabel("Bitrate thuc te (kbps)")
    ax.set_ylabel("SSIM (scale ve do phan giai nguon)")
    ax.set_title("Duong bitrate-SSIM")
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    path = out_dir / "bitrate_ssim.png"
    fig.savefig(path, dpi=120)
    plt.close(fig)
    created.append(path)

    fig, ax = plt.subplots(figsize=(7, 4.5))
    for video in videos:
        subset = [row for row in rows if row.video == video]
        fixed = sum(row.size_bytes for row in subset if row.method == "fixed")
        per_title = sum(row.size_bytes for row in subset if row.method == "per_title")
        ax.bar([f"{video}\nfixed", f"{video}\nper-title"], [fixed / 1024, per_title / 1024])
    ax.set_ylabel("Tong dung luong ladder (KB)")
    ax.set_title("Tong dung luong toan ladder")
    fig.tight_layout()
    path = out_dir / "ladder_total_size.png"
    fig.savefig(path, dpi=120)
    plt.close(fig)
    created.append(path)
    return created
