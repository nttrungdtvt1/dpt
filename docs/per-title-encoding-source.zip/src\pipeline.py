"""End-to-end per-title vs fixed ladder pipeline."""

from __future__ import annotations

import logging
from dataclasses import asdict
from pathlib import Path
from typing import Any

from analyzer.feature_extractor import extract_features
from config import AppConfig
from encoder.ffmpeg_encoder import encode_rung
from ladder.models import build_fixed_ladder, build_per_title_ladder, validate_ladder
from metrics.quality_metrics import measure_quality
from metrics.result_collector import ExperimentRow, row_from, write_csv, write_json
from utils.ffmpeg_tools import FFmpegTools
from utils.filesystem import ensure_dir, require_file, safe_stem
from visualization.plots import plot_results

logger = logging.getLogger("per_title")


def run_pipeline(
    videos: list[Path],
    output_dir: Path,
    tools: FFmpegTools,
    cfg: AppConfig,
) -> dict[str, Any]:
    if not videos:
        raise ValueError("Chua cung cap video dau vao.")
    output_dir = ensure_dir(output_dir)
    encodes_dir = ensure_dir(output_dir / "encodes")
    work_dir = ensure_dir(output_dir / "work")
    plots_dir = ensure_dir(output_dir / "plots")

    rows: list[ExperimentRow] = []
    analyses: list[dict[str, Any]] = []

    for raw in videos:
        video = require_file(raw, "video")
        logger.info("Phan tich %s", video.name)
        features = extract_features(video, tools, cfg, work_dir=work_dir)
        meta = features.meta
        k = features.adjusted_k
        label = features.adjusted_label
        fixed = build_fixed_ladder(meta, cfg)
        per_title = build_per_title_ladder(meta, cfg, k)
        validate_ladder(fixed, meta, cfg)
        validate_ladder(per_title, meta, cfg)
        analyses.append(
            {
                "video": video.name,
                "width": meta.width,
                "height": meta.height,
                "fps": meta.fps,
                "duration_seconds": meta.duration_seconds,
                "source_codec": meta.codec,
                "source_bitrate_bps": meta.bitrate_bps,
                "si": features.complexity.si,
                "ti": features.complexity.ti,
                "complexity_index": features.complexity.index,
                "complexity_label": label,
                "k": k,
                "probe_bitrate_kbps": features.probe_bitrate_kbps,
                "fixed_ladder": [asdict(rung) for rung in fixed],
                "per_title_ladder": [asdict(rung) for rung in per_title],
            }
        )
        stem = safe_stem(video)
        for method, ladder in (("fixed", fixed), ("per_title", per_title)):
            method_dir = ensure_dir(encodes_dir / stem / method)
            for rung in ladder:
                logger.info("Encode %s %s %s @ %s kbps", video.name, method, rung.name, rung.bitrate_kbps)
                encoded = encode_rung(video, meta, rung, method, method_dir, tools, cfg)
                quality = measure_quality(encoded.output, video, meta, tools, cfg)
                rows.append(
                    row_from(
                        video.name,
                        encoded,
                        quality,
                        label,
                        features.complexity.index,
                        k,
                    )
                )

    csv_path = output_dir / "experiment_results.csv"
    json_path = output_dir / "experiment_results.json"
    write_csv(csv_path, rows)
    payload = {
        "disclaimer": (
            "Day la ket qua lua chon bitrate ladder theo noi dung o muc thu nghiem, "
            "khong phai toi uu toan cuc."
        ),
        "analyses": analyses,
        "rows": [asdict(row) for row in rows],
    }
    write_json(json_path, payload)
    plot_files = plot_results(rows, plots_dir)
    return {
        "output_dir": str(output_dir),
        "csv": str(csv_path),
        "json": str(json_path),
        "plots": [str(path) for path in plot_files],
        "row_count": len(rows),
        "analyses": analyses,
    }
