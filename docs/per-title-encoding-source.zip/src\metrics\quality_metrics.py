"""Full-reference quality metrics via FFmpeg filters.

VMAF is optional and disabled unless libvmaf is present and config enables it.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from analyzer.video_probe import VideoMeta
from config import AppConfig
from utils.ffmpeg_tools import FFmpegTools, run_ffmpeg


@dataclass(frozen=True)
class QualityScores:
    psnr_average: float | None
    ssim_all: float | None
    vmaf: float | None
    notes: str


_PSNR_RE = re.compile(r"average:([0-9.]+)")
_SSIM_RE = re.compile(r"All:([0-9.]+)")
_VMAF_RE = re.compile(r"VMAF score:\s*([0-9.]+)", re.I)


def _run_filter(tools: FFmpegTools, encoded: Path, reference: Path, width: int, height: int, filter_name: str) -> str:
    filt = (
        f"[0:v]scale={width}:{height}:flags=bicubic,setsar=1[d];"
        f"[1:v]setsar=1[r];[d][r]{filter_name}"
    )
    args = [
        str(tools.ffmpeg),
        "-hide_banner",
        "-i",
        str(encoded),
        "-i",
        str(reference),
        "-filter_complex",
        filt,
        "-f",
        "null",
        "-",
    ]
    completed = run_ffmpeg(args, timeout=300)
    return (completed.stderr or "") + (completed.stdout or "")


def measure_quality(
    encoded: Path,
    reference: Path,
    source_meta: VideoMeta,
    tools: FFmpegTools,
    cfg: AppConfig,
) -> QualityScores:
    notes: list[str] = []
    psnr_val = None
    ssim_val = None
    vmaf_val = None
    width, height = source_meta.width, source_meta.height
    if cfg.quality.get("psnr", True):
        text = _run_filter(tools, encoded, reference, width, height, "psnr")
        match = _PSNR_RE.search(text)
        if not match:
            raise RuntimeError(f"Khong parse duoc PSNR cho {encoded.name}.\n{text[-800:]}")
        psnr_val = float(match.group(1))
    if cfg.quality.get("ssim", True):
        text = _run_filter(tools, encoded, reference, width, height, "ssim")
        match = _SSIM_RE.search(text)
        if not match:
            raise RuntimeError(f"Khong parse duoc SSIM cho {encoded.name}.\n{text[-800:]}")
        ssim_val = float(match.group(1))
    if cfg.quality.get("vmaf", False):
        text = _run_filter(
            tools,
            encoded,
            reference,
            width,
            height,
            "libvmaf",
        )
        match = _VMAF_RE.search(text)
        if match:
            vmaf_val = float(match.group(1))
        else:
            notes.append("VMAF duoc bat trong config nhung FFmpeg khong tra ve diem (thieu libvmaf).")
    else:
        notes.append("VMAF tat. Dung PSNR/SSIM.")
    return QualityScores(psnr_average=psnr_val, ssim_all=ssim_val, vmaf=vmaf_val, notes="; ".join(notes))
