"""Generate the Vietnamese student report from measured results."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
DOCS = ROOT / "docs"


def set_run_font(run, name: str = "Times New Roman", size: int = 13) -> None:
    run.font.name = name
    run.font.size = Pt(size)
    r = run._element
    rpr = r.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), name)


def add_heading(doc: Document, text: str, level: int) -> None:
    p = doc.add_heading(text, level=level)
    for run in p.runs:
        set_run_font(run, size=16 if level == 1 else 14)


def para(doc: Document, text: str, *, bold: bool = False) -> None:
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(1)
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.line_spacing = 1.5
    run = p.add_run(text)
    run.bold = bold
    set_run_font(run)


def caption(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(text)
    run.italic = True
    set_run_font(run, size=12)


def add_table(doc: Document, headers: list[str], rows: list[list[str]], title: str) -> None:
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = "Table Grid"
    for i, h in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = ""
        run = cell.paragraphs[0].add_run(h)
        run.bold = True
        set_run_font(run, size=11)
    for r_i, row in enumerate(rows, start=1):
        for c_i, value in enumerate(row):
            cell = table.rows[r_i].cells[c_i]
            cell.text = ""
            run = cell.paragraphs[0].add_run(value)
            set_run_font(run, size=11)
    caption(doc, title)


def add_picture(doc: Document, path: Path, title: str) -> None:
    if not path.is_file():
        para(doc, f"(Chua co hinh {path.name}.)")
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(path), width=Cm(14.5))
    caption(doc, title)


def load_rows() -> list[dict[str, str]]:
    csv_path = RESULTS / "experiment_results.csv"
    if not csv_path.is_file():
        return []
    with csv_path.open(encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def load_json() -> dict:
    path = RESULTS / "experiment_results.json"
    if not path.is_file():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def fmt(value: object, digits: int = 3) -> str:
    try:
        return f"{float(value):.{digits}f}"
    except (TypeError, ValueError):
        return str(value) if value not in (None, "") else "—"


def build() -> Path:
    DOCS.mkdir(parents=True, exist_ok=True)
    rows = load_rows()
    payload = load_json()
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Cm(2.5)
    section.bottom_margin = Cm(2.5)
    section.left_margin = Cm(3)
    section.right_margin = Cm(2)

    t = doc.add_paragraph()
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = t.add_run("TRƯỜNG ĐẠI HỌC GIAO THÔNG VẬN TẢI\nKHOA ĐIỆN – ĐIỆN TỬ")
    r.bold = True
    set_run_font(r, size=14)

    t = doc.add_paragraph()
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = t.add_run("\nBÁO CÁO BÀI TẬP LỚN\nMôn: Kỹ thuật đa phương tiện")
    r.bold = True
    set_run_font(r, size=16)

    t = doc.add_paragraph()
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = t.add_run(
        "Lựa chọn bitrate ladder theo từng nội dung\n"
        "(Per-Title Encoding) cho hệ thống Video on Demand\n"
        "bằng FFmpeg và Python"
    )
    r.bold = True
    set_run_font(r, size=14)

    para(
        doc,
        "Ghi chú phạm vi: đây là hệ thống lựa chọn bitrate ladder theo đặc trưng nội dung "
        "ở mức thử nghiệm (content-aware bitrate ladder selection), không phải thuật toán "
        "tối ưu toàn cục và không mô phỏng đầy đủ pipeline thương mại của Netflix.",
    )

    add_heading(doc, "Mục lục", 1)
    para(
        doc,
        "Mở tài liệu trong Microsoft Word, bấm vào mục lục và chọn Update Field nếu cần làm mới số trang.",
    )

    add_heading(doc, "Chương 1. Tổng quan đề tài", 1)
    add_heading(doc, "1.1. Bối cảnh Video on Demand", 2)
    para(
        doc,
        "Video on Demand (VOD) cho phép người xem mở nội dung đã mã hóa sẵn tại thời điểm "
        "bất kỳ. Nền tảng phát trực tuyến thường không gửi một file duy nhất mà chuẩn bị "
        "nhiều phiên bản cùng một video, khác nhau về độ phân giải và bitrate. Trình phát "
        "chọn phiên bản phù hợp với băng thông. Tập các phiên bản đó gọi là bitrate ladder.",
    )
    add_heading(doc, "1.2. Vấn đề của bitrate ladder cố định", 2)
    para(
        doc,
        "Ladder cố định gán cùng một bảng bitrate–độ phân giải cho mọi tựa. Nội dung ít chi "
        "tiết (phim hoạt hình phẳng, talkshow, thanh màu) bị cấp thừa bit. Nội dung khó nén "
        "(cảnh đông, texture, chuyển động nhanh) bị thiếu bit, xuất hiện khối và vỡ chi tiết. "
        "Độ phân giải không đủ để quyết định bitrate vì hai video 1080p có thể khác nhau rất "
        "nhiều về entropy không-thời gian.",
    )
    add_heading(doc, "1.3. Khái niệm Per-Title Encoding", 2)
    para(
        doc,
        "Per-Title Encoding, được Netflix mô tả năm 2015, điều chỉnh công thức mã hóa theo "
        "từng tựa: chạy phân tích và encode thử, rồi chọn cặp resolution–bitrate phù hợp độ "
        "phức tạp. Hệ thống đồ án này học ý tưởng đó nhưng thu hẹp: ước lượng SI/TI, nhân "
        "hệ số k lên ladder cố định, rồi kiểm chứng bằng PSNR/SSIM. Không triển khai convex "
        "hull, per-shot hay Dynamic Optimizer.",
    )
    add_heading(doc, "1.4. Mục tiêu, phạm vi và ý nghĩa", 2)
    para(
        doc,
        "Mục tiêu: xây dựng demo chạy trên máy cá nhân, so sánh ladder cố định với ladder "
        "theo nội dung, có số liệu thật và báo cáo bảo vệ được. Phạm vi: H.264/AVC, clip "
        "ngắn, tối đa bốn bậc 360p–1080p, không HLS/DASH, không GPU, không API trả phí. "
        "Ý nghĩa: minh họa đánh đổi bitrate–chất lượng–dung lượng, đúng trọng tâm môn "
        "Kỹ thuật đa phương tiện.",
    )

    add_heading(doc, "Chương 2. Cơ sở lý thuyết", 1)
    add_heading(doc, "2.1. Video số, độ phân giải, FPS và bitrate", 2)
    para(
        doc,
        "Một video số là chuỗi khung hình theo thời gian. Độ phân giải là số pixel mỗi khung. "
        "Frame rate (FPS) là số khung mỗi giây. Bitrate là số bit trung bình mỗi giây sau nén. "
        "Dung lượng xấp xỉ bitrate nhân thời lượng. Tăng bitrate thường tăng chất lượng nhưng "
        "không tuyến tính: khi đã bão hòa, thêm bit gần như không còn lợi ích nhìn thấy.",
    )
    add_heading(doc, "2.2. Nén video, H.264, I/P/B và GOP", 2)
    para(
        doc,
        "Nén video khai thác dư thừa không gian trong một khung và dư thừa thời gian giữa các "
        "khung. H.264/AVC dùng dự đoán trong khung, ước lượng chuyển động và mã hóa phần dư. "
        "I-frame mã độc lập, P-frame dự đoán từ khung trước, B-frame dự đoán hai hướng. "
        "GOP (Group of Pictures) là khoảng từ I-frame này đến I-frame kế. Với VOD/ABR, "
        "demo đặt khoảng keyframe khoảng 2 giây để seek và cắt segment thuận tiện.",
    )
    add_heading(doc, "2.3. Rate control: CBR, VBR, CRF, ABR", 2)
    para(
        doc,
        "CBR giữ bitrate gần như phẳng, phù hợp live hơn VOD. CRF nhắm chất lượng cảm nhận, "
        "để bitrate tự thay đổi; dùng tốt khi đo độ khó nén (probe) nhưng không tạo được "
        "các bậc băng thông cố định. ABR/VBR two-pass nhắm một bitrate trung bình khá đúng. "
        "Trong demo, encode chính dùng -b:v (ABR một pass, có thể bật two-pass trong config) "
        "vì đối tượng so sánh là bitrate ladder.",
    )
    add_heading(doc, "2.4. VOD, Adaptive Bitrate Streaming và ladder", 2)
    para(
        doc,
        "ABR chia video thành segment, mỗi mức chất lượng một luồng. Player đổi mức khi mạng "
        "thay đổi. Bitrate ladder là tập (độ phân giải, bitrate mục tiêu). Apple công bố bảng "
        "gợi ý H.264 trong HLS Authoring Specification và ghi rõ đó là starting target, cần "
        "chỉnh theo nội dung. Đồ án lấy bốn mức 640×360 @ 365 kbps, 768×432 @ 730 kbps, "
        "1280×720 @ 3000 kbps, 1920×1080 @ 6000 kbps làm baseline.",
    )
    add_heading(doc, "2.5. Chỉ số chất lượng và đánh đổi", 2)
    para(
        doc,
        "PSNR = 10 log10 (MAX^2 / MSE), đơn vị dB, dễ tính nhưng kém khớp cảm nhận. SSIM so "
        "sánh độ sáng, tương phản và cấu trúc, thường gần mắt người hơn PSNR. VMAF của Netflix "
        "hợp nhất nhiều đặc trưng và học từ MOS; demo tắt VMAF mặc định vì nhiều bản FFmpeg "
        "Windows không có libvmaf. Mọi PSNR/SSIM được đo sau khi scale bản encode về đúng "
        "độ phân giải nguồn, nếu không các bậc 360p và 720p không so được. Bitrate thấp hơn "
        "không đồng nghĩa chất lượng tốt hơn; phải đọc cùng PSNR/SSIM và dung lượng.",
    )
    para(
        doc,
        "Spatial Information (SI) ước lượng chi tiết trong khung (độ lệch chuẩn sau Sobel). "
        "Temporal Information (TI) ước lượng thay đổi giữa hai khung liên tiếp. ITU-T P.910 "
        "dùng SI/TI để chọn clip thử. Demo lấy mẫu vài khung/giây, lấy trung vị, chuẩn hóa "
        "theo mốc si_ref và ti_ref. Đây là ước lượng, không phải phép đo P.910 đầy đủ.",
    )

    add_heading(doc, "Chương 3. Phân tích và thiết kế hệ thống", 1)
    add_heading(doc, "3.1. Yêu cầu", 2)
    para(
        doc,
        "Chức năng: kiểm tra FFmpeg, đọc metadata, ước lượng phức tạp, sinh hai ladder, encode, "
        "đo PSNR/SSIM, xuất CSV/JSON và biểu đồ. Phi chức năng: chạy máy cá nhân, không ghi đè "
        "file gốc, lệnh FFmpeg dạng list (an toàn với đường dẫn có dấu cách), lặp lại được thí nghiệm.",
    )
    add_heading(doc, "3.2. Kiến trúc và luồng xử lý", 2)
    para(
        doc,
        "Luồng: video vào → FFprobe metadata → lấy mẫu khung tính SI/TI → gán nhãn easy/medium/hard "
        "và hệ số k → ladder cố định (lọc bậc cao hơn nguồn) → ladder per-title (bitrate × k, "
        "làm tròn, kẹp min/max, bắt tăng dần) → FFmpeg libx264 từng bậc → đo PSNR/SSIM → "
        "ghi CSV/JSON và vẽ đồ thị.",
    )
    add_table(
        doc,
        ["Module", "Input", "Output"],
        [
            ["video_probe", "File video", "width, height, fps, duration, codec, bitrate"],
            ["complexity", "Video + metadata", "SI, TI, index, nhãn, k"],
            ["fixed_ladder", "Metadata", "Danh sách bậc Apple đã lọc"],
            ["per_title_ladder", "Metadata + k", "Danh sách bậc đã nhân k"],
            ["ffmpeg_encoder", "Video + bậc", "File mp4, thời gian, bitrate thật, size"],
            ["quality_metrics", "Gốc + encode", "PSNR, SSIM"],
            ["result_collector / plots", "Các dòng đo", "CSV, JSON, PNG"],
        ],
        "Bảng 3.1. Module chính của demo",
    )
    add_heading(doc, "3.3. Thuật toán lựa chọn ladder", 2)
    para(
        doc,
        "Chỉ số phức tạp: C = 0,55 × (SI / si_ref) + 0,45 × (TI / ti_ref), cắt [0; 1,5]. "
        "Nếu C < 0,35 thì easy (k = 0,65); nếu C ≥ 0,65 thì hard (k = 1,35); còn lại medium "
        "(k = 1,0). Các ngưỡng này là hằng số thí nghiệm, có thể hiệu chỉnh. Không upscale. "
        "Không xóa bậc thấp khi nội dung khó vì ABR vẫn cần mức cho mạng yếu. Bitrate per-title "
        "làm tròn bước 50 kbps.",
    )
    para(
        doc,
        "Vì sao chuyển động cần nhiều bit: dự đoán liên khung kém, phần dư lớn. Vì sao cảnh "
        "phẳng cần ít bit: nhiều vùng dự đoán tốt, hệ số biến đổi gần 0. Vì sao không chỉ dựa "
        "độ phân giải: cùng 720p, thanh màu SMPTE khác hẳn testsrc2 về entropy. Sau encode bắt "
        "buộc đo chất lượng vì k chỉ là heuristic.",
    )
    add_heading(doc, "3.4. Công nghệ", 2)
    para(
        doc,
        "Python 3.12, FFmpeg/FFprobe, NumPy, Matplotlib, PyYAML, pytest. Không dùng OpenCV "
        "(tránh phụ thuộc nặng; khung được FFmpeg xuất raw gray). Không tự tải mô hình AI.",
    )

    add_heading(doc, "Chương 4. Xây dựng demo", 1)
    para(
        doc,
        "Môi trường đã kiểm trên Windows: Python 3.12.10, FFmpeg Gyan 9.0.1, thư viện trong "
        "requirements.txt. Cài đặt và lệnh chạy ghi trong README.md. Cấu hình nằm ở "
        "config/config.yaml (codec, preset, ladder, ngưỡng k). VMAF tắt. Two-pass tắt mặc định "
        "để demo nhanh; bật được bằng two_pass: true.",
    )
    para(
        doc,
        "Giao diện là CLI: check-env, make-sample, analyze, run. Kết quả trực quan là bảng CSV "
        "và các PNG trong results/plots. Không làm Streamlit trong phiên bản này để giảm rủi ro "
        "cài đặt; có thể bổ sung sau khi pipeline ổn.",
    )

    add_heading(doc, "Chương 5. Thực nghiệm và đánh giá", 1)
    add_heading(doc, "5.1. Thiết lập", 2)
    para(
        doc,
        "Ba clip lavfi 1280×720, 25 fps, 4 giây: testsrc, smptebars, testsrc2. Thông số giữ "
        "cố định: libx264, preset veryfast, GOP 2 s, không audio, cùng bộ lọc scale bicubic. "
        "Thông số thay đổi: cặp height–bitrate theo từng phương pháp. Nguồn 720p nên bậc 1080p "
        "bị loại, đúng ràng buộc không upscale. Số liệu dưới đây đo được trên máy thực hành, "
        "không phải số minh họa.",
    )

    if payload.get("analyses"):
        analysis_rows = []
        for item in payload["analyses"]:
            analysis_rows.append(
                [
                    item["video"],
                    f"{item['width']}x{item['height']}",
                    fmt(item["si"], 2),
                    fmt(item["ti"], 2),
                    fmt(item["complexity_index"], 3),
                    str(item["complexity_label"]),
                    fmt(item["k"], 2),
                ]
            )
        add_table(
            doc,
            ["Video", "Size", "SI", "TI", "C", "Nhãn", "k"],
            analysis_rows,
            "Bảng 5.1. Đặc trưng đo được (ước lượng SI/TI)",
        )

    if rows:
        data_rows = []
        for row in rows:
            data_rows.append(
                [
                    row["video"].replace(".mp4", ""),
                    row["method"],
                    row["rung"],
                    row["target_bitrate_kbps"],
                    fmt(row["actual_bitrate_kbps"], 1),
                    str(int(int(row["size_bytes"]) / 1024)),
                    fmt(row["psnr"], 2),
                    fmt(row["ssim"], 4),
                ]
            )
        add_table(
            doc,
            ["Video", "PP", "Bậc", "Target kbps", "Thực kbps", "KB", "PSNR", "SSIM"],
            data_rows,
            "Bảng 5.2. Kết quả encode và chất lượng đo được",
        )

    add_picture(doc, RESULTS / "plots" / "file_size_by_rung.png", "Hình 5.1. Dung lượng từng bậc")
    add_picture(doc, RESULTS / "plots" / "bitrate_ssim.png", "Hình 5.2. Bitrate thực tế và SSIM")
    add_picture(doc, RESULTS / "plots" / "ladder_total_size.png", "Hình 5.3. Tổng dung lượng toàn ladder")

    add_heading(doc, "5.2. Phân tích kết quả đo", 2)
    para(
        doc,
        "smptebars gần như tĩnh (TI = 0). Encoder chỉ dùng khoảng 20–33 kbps dù target 365–3000 kbps; "
        "PSNR 720p khoảng 87 dB, SSIM = 1. Nội dung dễ nén không cần ladder cao. Bộ phân loại SI/TI "
        "gán medium vì thanh màu có nhiều cạnh, nên k = 1 và per-title gần như trùng fixed. Đây là "
        "hạn chế của heuristic: SI cao không luôn nghĩa là khó nén theo nghĩa bitrate thực.",
    )
    para(
        doc,
        "testsrc bị gán hard vì SI lớn (hoa văn hình học). Tăng target gần như không đổi SSIM ở 360p "
        "(khoảng 0,964). Ở 720p PSNR đã rất cao (khoảng 69–71 dB) vì nguồn là pattern đơn giản; "
        "bitrate thực thấp hơn target nhiều. Per-title tốn thêm dung lượng mà lợi ích cảm nhận gần như "
        "không có. Không được kết luận per-title luôn tiết kiệm hay luôn tốt hơn.",
    )
    para(
        doc,
        "testsrc2 gần nội dung phức tạp hơn: bitrate thực bám target. Per-title (k = 1,35) tăng "
        "bitrate và dung lượng, PSNR 720p tăng từ khoảng 45,2 dB lên 48,9 dB, SSIM từ 0,996 lên "
        "0,998. Với nội dung khó, heuristic đang đổi thêm bit lấy thêm chất lượng, đúng hướng "
        "bảo vệ chất lượng chứ không phải tiết kiệm băng thông.",
    )
    para(
        doc,
        "Kết luận thực nghiệm: hệ thống chạy đúng quy trình, không upscale, xuất số liệu lặp lại "
        "được. Lợi ích per-title phụ thuộc nội dung. Clip lavfi không thay thế phim thật; cần thêm "
        "video camera (cảnh tĩnh, cảnh đông) trước khi phát biểu về hiệu quả lưu trữ.",
    )
    add_heading(doc, "5.3. Hạn chế và hướng mở rộng", 2)
    para(
        doc,
        "Hạn chế: clip tổng hợp ngắn; ngưỡng SI/TI chưa hiệu chỉnh trên kho phim; chưa CRF probe "
        "(tắt trong config); chưa VMAF; ABR một pass nên bitrate thực có thể lệch target; chưa "
        "đóng gói HLS. Mở rộng: bật probe CRF, hiệu chỉnh k trên tập clip thật, VMAF nếu build "
        "FFmpeg có libvmaf, convex hull nhiều CRF, HLS, two-pass.",
    )

    add_heading(doc, "Chương 6. Kết luận", 1)
    para(
        doc,
        "Đã xây dựng demo Python + FFmpeg lựa chọn bitrate ladder theo nội dung ở mức thử nghiệm, "
        "so với ladder cố định lấy từ gợi ý Apple HLS, đo PSNR/SSIM, có test tự động và số liệu thật. "
        "Chưa hoàn thiện: VMAF, hull, dữ liệu phim thật, giao diện web. Hướng phát triển: hiệu chỉnh "
        "heuristic bằng encode thử, rồi mới bàn đến tối ưu RD.",
    )

    add_heading(doc, "Tài liệu tham khảo", 1)
    refs = [
        "Aaron, A., Li, Z., Manohara, M., De Cock, J., Ronca, D. (2015). Per-Title Encode Optimization. Netflix TechBlog. https://netflixtechblog.com/per-title-encode-optimization-7e99442b62a2",
        "Apple. HTTP Live Streaming authoring specification for Apple devices. https://developer.apple.com/documentation/http-live-streaming/hls-authoring-specification-for-apple-devices",
        "FFmpeg Project. FFmpeg Documentation. https://ffmpeg.org/ffmpeg.html",
        "FFmpeg Project. FFprobe Documentation. https://ffmpeg.org/ffprobe.html",
        "FFmpeg Project. Encode/H.264. https://trac.ffmpeg.org/wiki/Encode/H.264",
        "Robitza, W. (2017). CRF Guide (x264, x265 and libvpx). https://slhck.info/video/2017/02/24/crf-guide.html",
        "Li, Z. et al. (2016). Toward A Practical Perceptual Video Quality Metric. Netflix TechBlog. https://netflixtechblog.com/toward-a-practical-perceptual-video-quality-metric-653f208b9652",
        "Netflix. VMAF: The Journey Continues (2018). https://netflixtechblog.com/vmaf-the-journey-continues-44b51ee9ed12",
        "Netflix. VMAF GitHub repository. https://github.com/Netflix/vmaf",
        "ITU-T. Recommendation P.910: Subjective video quality assessment methods for multimedia applications. https://www.itu.int/rec/T-REC-P.910",
        "Wang, Z., Bovik, A. C., Sheikh, H. R., Simoncelli, E. P. (2004). Image quality assessment: from error visibility to structural similarity. IEEE TIP, 13(4), 600–612. https://doi.org/10.1109/TIP.2003.819861",
        "Katsavounidis, I. (2018). Dynamic Optimizer — A Perceptual Video Encoding Optimization Framework. Netflix TechBlog. https://netflixtechblog.com/dynamic-optimizer-a-perceptual-video-encoding-optimization-framework-e19f1e3a277f",
        "Bjøntegaard, G. (2001). Calculation of average PSNR differences between RD-curves. ITU-T SG16 Q.6 VCEG-M33.",
        "Robitza, W. ffmpeg-quality-metrics. https://github.com/slhck/ffmpeg-quality-metrics",
        "ITU-T. H.264: Advanced video coding for generic audiovisual services. https://www.itu.int/rec/T-REC-H.264",
    ]
    for i, item in enumerate(refs, start=1):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Cm(0.75)
        p.paragraph_format.first_line_indent = Cm(-0.75)
        run = p.add_run(f"[{i}] {item}")
        set_run_font(run, size=12)

    add_heading(doc, "Phụ lục A. Kiểm thử", 1)
    para(
        doc,
        "Bộ pytest gồm kiểm tra FFmpeg, probe file thiếu/file không phải video, SI/TI trên ảnh tổng hợp, "
        "không upscale, bitrate tăng dần, lệnh FFmpeg dạng list với đường dẫn có dấu cách, xuất CSV/JSON, "
        "vẽ biểu đồ, và pipeline encode clip 1,2 giây. Lần chạy gần nhất: 23 passed.",
    )

    out = DOCS / "BaoCao_PerTitle_VOD.docx"
    doc.save(out)
    return out


if __name__ == "__main__":
    path = build()
    print(path)
