# Per-Title Bitrate Ladder Selection cho VOD

Công cụ Python + FFmpeg để **lựa chọn bitrate ladder theo nội dung** (content-aware, mức thử nghiệm) và so sánh với **ladder cố định**. Đây không phải hệ thống tối ưu thương mại kiểu Netflix.

## Cần cài đặt

- Python 3.11+ (đã kiểm thử 3.12)
- FFmpeg và FFprobe (có `libx264`)

Trên Windows:

```text
winget install --id Python.Python.3.12 -e
winget install --id Gyan.FFmpeg -e
```

Mở lại terminal để PATH nhận FFmpeg.

## Cài đặt dự án

```text
cd per-title-encoding
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

Kiểm tra môi trường:

```text
python src\main.py check-env
```

## Tạo video mẫu

```text
python src\main.py make-sample --output data\samples\testsrc_720p.mp4 --seconds 4 --size 1280x720 --pattern testsrc
python src\main.py make-sample --output data\samples\smptebars_720p.mp4 --seconds 4 --size 1280x720 --pattern smptebars
python src\main.py make-sample --output data\samples\testsrc2_720p.mp4 --seconds 4 --size 1280x720 --pattern testsrc2
```

## Chạy pipeline

```text
python src\main.py analyze data\samples\testsrc_720p.mp4
python src\main.py run data\samples\testsrc_720p.mp4 data\samples\smptebars_720p.mp4 data\samples\testsrc2_720p.mp4 --output results
```

Kết quả trong `results/`: CSV, JSON, file encode, biểu đồ PNG.

Tạo lại báo cáo Word từ số liệu vừa đo:

```text
python tools\build_report.py
```

File: `docs/BaoCao_PerTitle_VOD.docx`.

## Kiểm thử

```text
python -m pytest -q
```

## Thuật toán (tóm tắt)

1. FFprobe đọc metadata.
2. Ước lượng SI/TI trên khung lấy mẫu.
3. Gán nhãn easy/medium/hard và hệ số `k`.
4. Ladder cố định: bốn mức rút từ Apple HLS Authoring Spec.
5. Ladder per-title: `bitrate = clamp(k × bitrate_cố_định)`, không upscale.
6. Encode `libx264` với `-b:v`.
7. Đo PSNR/SSIM sau khi scale về độ phân giải nguồn.

VMAF tắt mặc định.

## Giới hạn

Không HLS/DASH, không per-shot, không convex hull, không BD-Rate. Không gọi kết quả là tối ưu toàn cục.
